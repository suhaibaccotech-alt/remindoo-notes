CREATE OR REPLACE FUNCTION for_tasks.refresh_ch_tasks(
    p_reference_date DATE,
    p_client_id BIGINT,
    p_chosen_service BIGINT
)
RETURNS TEXT
SECURITY DEFINER
LANGUAGE plpgsql
AS
$$
DECLARE
new_task_name TEXT;
BEGIN

-- Step 1: Prepare the refresh data for this service (merged with selected_service)
WITH refresh_service AS MATERIALIZED (
    SELECT
        CASE 
            WHEN fst.i_deadline_reference_status IS NULL THEN p_reference_date + fi.interval_value::INTERVAL + (fst.i_deadline_offset_days || ' days')::INTERVAL
            ELSE NULL
        END AS val_i_deadline,
        fst.e_deadline_settings,
        fst.e_deadline_offset_days,
        fst.e_deadline_offset_months,
        fst.e_deadline_custom_day,
        fst.e_deadline_custom_month,
        fst.frequency AS fst_frequency,
        for_services.replace_tokens(tt.name, cs.custom_fields, p_client_id) AS tt_name,
        tt.id AS tt_id,
        tt.description AS tt_description,
        tt.priority AS tt_priority,
        cl.client_name,
        cl.client_type,
        tt.is_billable AS tt_is_billable,
        cs.name AS service_name,
        cl.emails AS client_emails,
        tt.tags AS tt_tags,
        fst.id AS freq_settings,
        cs.service_template AS tt_service_template
    FROM chosen_services cs
    INNER JOIN service_templates st ON st.id = cs.service_template
    INNER JOIN clients cl ON cl.id = p_client_id
    INNER JOIN task_templates tt ON cs.service_template = tt.service_template
    INNER JOIN frequency_settings_templates fst ON fst.task_template = tt.id AND fst.frequency = cs.frequency
    INNER JOIN for_misc.frequency_intervals fi ON fst.frequency = fi.frequency
    WHERE cs.id = p_chosen_service
),

-- Step 2: Increment tasks_count in client
client_count_updated AS (
    UPDATE clients
    SET tasks_count = tasks_count + 1
    WHERE id = p_client_id
),
chosen_service_count_updated AS (
    UPDATE chosen_services
    SET tasks_count = tasks_count + 1
    WHERE id = p_chosen_service
),
-- Step 3: Insert new task
new_tasks AS (
    INSERT INTO tasks (
        name, chosen_service, description, priority, i_deadline, e_deadline,
        client_name, client_type, is_billable, service_name, tags, client,
        reference_date, freq_settings
    )
    SELECT
        tt_name || ' - ' || TO_CHAR(p_reference_date, 'DD-MM-YY'),
        p_chosen_service,
        tt_description,
        tt_priority,
        val_i_deadline,
        CASE e_deadline_settings
            WHEN 'Offset' THEN p_reference_date + (e_deadline_offset_days * INTERVAL '1 day') + (e_deadline_offset_months * INTERVAL '1 month')
            WHEN 'Day' THEN MAKE_DATE(EXTRACT(YEAR FROM p_reference_date)::INT, EXTRACT(MONTH FROM p_reference_date)::INT, e_deadline_custom_day)
            WHEN 'Month' THEN MAKE_DATE(EXTRACT(YEAR FROM p_reference_date)::INT, e_deadline_custom_month, e_deadline_custom_day)
            ELSE val_i_deadline
        END,
        client_name,
        client_type,
        tt_is_billable,
        service_name,
        tt_tags,
        p_client_id,
        p_reference_date,
        freq_settings
    FROM refresh_service
    RETURNING id,name, (
        SELECT array_agg(man.email)
        FROM managers_to_service mts
        INNER JOIN service_users man ON man.id = mts.employee
        WHERE mts.service = p_chosen_service
    ) AS manager_emails
),

-- Step 4: Build subtask data
subtask_cache AS (
    SELECT 
        nt.id AS task,
        st.name AS subtask_name,
        st.estimated_time,
        st.id AS sub_template_id
    FROM refresh_service rs
    INNER JOIN subtask_templates st ON st.task_template = rs.tt_id
    INNER JOIN new_tasks nt ON true
),

-- Step 5: Create new subtasks
new_subtasks AS MATERIALIZED (
    INSERT INTO subtasks (task, name, estimated_time)
    SELECT 
        task,
        subtask_name,
        estimated_time
    FROM subtask_cache
    RETURNING id, name, task
),

-- Step 6: Create subtask steps
new_subtask_steps AS (
    INSERT INTO subtask_steps (subtask, name)
    SELECT 
        new_sub.id,
        sst.name
    FROM new_subtasks new_sub
    INNER JOIN subtask_cache sub_cache ON new_sub.name = sub_cache.subtask_name AND new_sub.task = sub_cache.task
    INNER JOIN subtask_step_templates sst ON sst.subtask_template = sub_cache.sub_template_id
),

-- Step 7: Create checklists
new_checklists AS (
    INSERT INTO checklists(subject, description, service, task, status)
    SELECT 
        ct.subject,
        ct.description,
        p_chosen_service,
        nt.id,
        ct.status
    FROM new_tasks nt
    INNER JOIN refresh_service rs ON true
    INNER JOIN checklist_templates ct ON ct.service_template = rs.tt_service_template
),

-- Step 8: Map employees to tasks
employee_to_service_cache AS MATERIALIZED (
    SELECT 
        ets.employee,
        nt.id AS task_id
    FROM employee_to_service ets
    INNER JOIN new_tasks nt ON ets.service = p_chosen_service
),

-- Step 9: Get assignee emails
assignee_emails_cache AS MATERIALIZED (
    SELECT 
        ets.task_id,
        array_agg(su.email) AS emails
    FROM employee_to_service_cache ets
    INNER JOIN service_users su ON ets.employee = su.id
    GROUP BY ets.task_id
),

-- Step 10: Map employees to tasks
new_employee_task_maps AS (
    INSERT INTO employee_to_task(employee, task)
    SELECT employee, task_id FROM employee_to_service_cache
),

-- Step 11: Map employees to subtasks
new_employee_subtask_maps AS (
    INSERT INTO employee_to_subtask(employee, subtask)
    SELECT 
        ets_cache.employee,
        ns.id
    FROM employee_to_service_cache ets_cache
    INNER JOIN new_subtasks ns ON ns.task = ets_cache.task_id
),

-- Step 12: Prepare reminder templates
reminder_templates_data AS MATERIALIZED (
    SELECT
        p_chosen_service AS service,
        rt.id,
        rt.name,
        p_reference_date AS reference_date,
        rt.task_progress_status,
        rt.type_is_internal AS is_internal,
        new_tasks.id AS task,
        new_tasks.name AS task_name
    FROM new_tasks
    INNER JOIN refresh_service rs ON true
    INNER JOIN reminder_templates rt ON rt.service_template = rs.tt_service_template AND rs.fst_frequency = rt.frequency
),

-- Step 13: Insert reminders
new_reminders AS (
    INSERT INTO reminders(service, name, reference_date, task_progress_status, is_internal, task, task_name)
    SELECT service, name, reference_date, task_progress_status, is_internal, task, task_name
    FROM reminder_templates_data
    RETURNING id, name, service, reference_date
),

-- Step 14: Link reminders with email template data
rt_rem_etd AS MATERIALIZED(
    SELECT 
        rt.is_internal,
        etd.id AS email_template_data,
        etd.email_body,
        etd.bcc_list,
        etd.subject,
        nr.id AS reminder,
        CASE etd.is_before
            WHEN TRUE THEN p_reference_date - (etd.offset_days * INTERVAL '1 day')
            ELSE p_reference_date + (etd.offset_days * INTERVAL '1 day')
        END AS sending_date,
        etd.is_active,
        rt.task
    FROM reminder_templates_data rt
    INNER JOIN new_reminders nr ON nr.name = rt.name AND nr.service = rt.service
    INNER JOIN email_template_datas etd ON etd.reminder_template = rt.id
),

-- Step 15: Create email_datas
new_email_datas AS (
    INSERT INTO email_datas(email_body, subject, reminder, sending_date, is_active, task, recepient_emails, bcc_list_actual,email_template_data)
    SELECT 
        email_body,
        subject,
        reminder,
        sending_date,
        is_active,
        task,
        CASE rt_rem_etd.is_internal
            WHEN TRUE THEN ae.emails
            ELSE rs.client_emails
        END AS recepient_emails,
        (
            CASE WHEN 'Assignees' = ANY(bcc_list) THEN ae.emails ELSE ARRAY[]::text[] END ||
            CASE WHEN 'Service Managers' = ANY(bcc_list) THEN nt.manager_emails ELSE ARRAY[]::text[] END
        ),
        rt_rem_etd.email_template_data
    FROM rt_rem_etd
    INNER JOIN new_tasks nt ON nt.id = rt_rem_etd.task
    INNER JOIN refresh_service rs ON true
    INNER JOIN assignee_emails_cache ae ON ae.task_id = nt.id
    RETURNING id, sending_date, reminder, subject
),

new_email_searchs AS 
(

-- Step 16: Create email search records
    INSERT INTO email_searchs(subject, reminder, sending_date, is_active, email_data, status)
    SELECT 
        ets.subject,
        new_ed.reminder,
        new_ed.sending_date,
        rem_cache.is_active,
        new_ed.id,
        CASE 
            WHEN new_ed.sending_date < CURRENT_DATE THEN 'Draft'::email_status
            ELSE 'Queued'::email_status
        END
    FROM new_email_datas new_ed
    INNER JOIN rt_rem_etd rem_cache ON rem_cache.reminder = new_ed.reminder AND rem_cache.subject = new_ed.subject
    INNER JOIN email_template_searchs ets ON ets.email_template_data = rem_cache.email_template_data
)

    SELECT name INTO new_task_name FROM new_tasks LIMIT 1;

    RETURN new_task_name;

END;
$$;
