import {
	createClient
} from "@supabase/supabase-js";
import axios from "axios";
//import moment from "moment/moment.js";
import dotenv from "dotenv";
dotenv.config();



//PROD
const SUPABASE_URL = 'https://wkpsjfvbawooqsnjvzwa.supabase.co';
const SUPABASE_SERVICE_ROLE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndrcHNqZnZiYXdvb3Fzbmp2endhIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc0NTQ4MzY5NSwiZXhwIjoyMDYxMDU5Njk1fQ.25EoHkirwOODfFM2K_BdyD3BnHy86uxcdsm5nFOUnSQ";


//DEV
// const SUPABASE_URL = 'https://ipoirnflnbigbzrikqth.supabase.co';
// const SUPABASE_SERVICE_ROLE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imlwb2lybmZsbmJpZ2J6cmlrcXRoIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTcyNzk0NDE5NCwiZXhwIjoyMDQzNTIwMTk0fQ.U49WiUVfcYaGFIGCMhPvhJt3lptb3tmRj9bd-AZYBQE";


const supabase = createClient(
	SUPABASE_URL,
	SUPABASE_SERVICE_ROLE_KEY
);
const COMPANIES_HOUSE_API_KEY = process.env.COMPANIES_HOUSE_API_KEY;

// ----------------------------------
// Constants
// ----------------------------------
const CUSTOM_FIELD_TOKEN_MAP = {
	next_accounts_end_on: "::Next Accounts For The Period Ended::",
	accounts_due_on: "::Next Accounts Due Date::",
	last_accounts_end_on: "::Last Account Made up to::",
	cs_next_made_up_to: "::Next C.S Date::",
	cs_next_due: "::Next CS Due Date::",
	cs_last_made_up_to: "::Last C.S Filed Date::",
};

//------- FIELD MAPPINGS FOR CH SYNC TO SUPABASE --------------

const COMPANY_TYPE_MAPPING = {
	ltd: "Private Limited Company",
	plc: "Public Limited Company",
	llp: "Limited Liability Partnership",
	"limited-partnership": "Partnership",
	"oversea-company": "Overseas Company",
	other: "Other",
	"private-unlimited": "Private Unlimited",
	"old-public-company": "Old Public Company",
	"private-limited-guarant-nsc-limited-exemption": "Private Limited Guarant NSC Limited Exemption",
	"private-limited-guarant-nsc": "Private Limited Guarant NSC",
	"converted-or-closed": "Converted or Closed",
	"private-unlimited-nsc": "Private Unlimited NSC",
	"private-limited-shares-section-30-exemption": "Private Limited Shares Section 30 Exemption",
	"assurance-company": "Assurance Company",
	eeig: "EEIG",
	"icvc-securities": "ICVC Securities",
	"icvc-warrant": "ICVC Warrant",
	"icvc-umbrella": "ICVC Umbrella",
	"industrial-and-provident-society": "Industrial and Provident Society",
	"northern-ireland": "Northern Ireland",
	"nothern-ireland-other": "Northern Ireland Other",
	"royal-charter": "Royal Charter",
	"investment-company-with-variable-capital": "Investment Company with Variable Capital",
	"unregistered-company": "Unregistered Company",
	"european-public-limited-liability-company-se": "European Public Limited Liability Company SE",
	"registered-overseas-entity": "Registered Overseas Entity",
};

const FIELD_MAPPINGS = [{
		oldPath: "accounting_reference_day",
		newPath: "accounts.accounting_reference_date.day",
	},
	{
		oldPath: "accounting_reference_month",
		newPath: "accounts.accounting_reference_date.month",
	},
	{
		oldPath: "accounts_due_on",
		newPath: "accounts.next_accounts.due_on",
	},
	{
		oldPath: "accounts_overdue",
		newPath: "accounts.next_accounts.overdue",
	},
	{
		oldPath: "address",
		newPath: "registered_office_address.address_line_1",
	},
	{
		oldPath: "city_name",
		newPath: "registered_office_address.locality",
	},
	{
		oldPath: "client_name",
		newPath: "company_name"
	},
	{
		oldPath: "client_type",
		newPath: "type"
	},
	{
		oldPath: "company_name",
		newPath: "company_name"
	},
	{
		oldPath: "cs_next_due",
		newPath: "confirmation_statement.next_due",
	},
	{
		oldPath: "cs_next_made_up_to",
		newPath: "confirmation_statement.next_made_up_to",
	},
	{
		oldPath: "cs_overdue",
		newPath: "confirmation_statement.overdue",
	},
	{
		oldPath: "incorporation_date",
		newPath: "date_of_creation",
	},
	{
		oldPath: "postal_code",
		newPath: "registered_office_address.postal_code",
	},
	{
		oldPath: "registered_in",
		newPath: "registered_office_address.country",
	},
	{
		oldPath: "sic_codes",
		newPath: "sic_codes"
	},
	{
		oldPath: "ch_status",
		newPath: "company_status"
	},
	{
		oldPath: "last_accounts_end_on",
		newPath: "accounts.last_accounts.period_end_on",
	},
	{
		oldPath: "cs_last_made_up_to",
		newPath: "confirmation_statement.last_made_up_to",
	},
	{
		oldPath: "next_accounts_end_on",
		newPath: "accounts.next_accounts.period_end_on",
	},
	{
		oldPath: "company_status_detail",
		newPath: "company_status_detail",
	},
];


const CH_SERVICES = [{
		name: "Accounts - Year End + CT600",
		fields: [
			"next_accounts_end_on",
			"accounts_due_on",
			"last_accounts_end_on",
		],
		keyField: "last_accounts_end_on",
		refField: "next_accounts_end_on"
	},
	{
		name: "Confirmation Statement",
		fields: [
			"cs_next_due",
			"cs_next_made_up_to",
			"cs_last_made_up_to",
		],
		keyField: "cs_last_made_up_to",
		refField: "cs_next_made_up_to"
	}
];


const columnsForTaskUpdate = `,
        reminders:reminders(
          email_datas (
            id, 
            email_template_data (
              offset_days,
              is_before
            )
          )
        ),
        tasks (
          frequency_settings:frequency_settings_templates (
            *
          )
        )`;

// ----------------------------------
// Utility Functions
// ----------------------------------
const getNested = (obj, path) =>
	path.split(".").reduce((acc, part) => acc?.[part], obj);

const sanitizeValue = (val) =>
	typeof val === "string" ? val.trim().toLowerCase() : val;

const updateCustomFields = (customFields, changes) => {
	return customFields.map((field) => {
		const change = changes.find(
			(c) => CUSTOM_FIELD_TOKEN_MAP[c.field] === field.token
		);
		return change ?
			{
				...field,
				date_val: new Date(change.newValue + "T00:00:00.000Z").toISOString()
			} :
			field;
	});
};

// ----------------------------------
// External API Fetch
// ----------------------------------
const fetchCompanyData = async (companyNumber) => {
	const url = `https://api.company-information.service.gov.uk/company/${companyNumber}`;
	try {
		const response = await axios.get(url, {
			auth: {
				username: COMPANIES_HOUSE_API_KEY,
				password: ""
			},
		});
		return response.data;
	} catch (error) {
		console.error(`CH API error for company ${companyNumber}:`, error.message);
		throw new Error(
			`CH API error: ${error.response?.status} ${error.response?.statusText}`
		);
	}
};

const fetchStoredClients = async (companyNumbers) => {
	try {

		//Get required fields of the clients of those companyNumbers  
		const {
			data,
			error
		} = await supabase
			.from("clients")
			.select("id,company_number," + FIELD_MAPPINGS.map((f) => f.oldPath).join(","))
			.in("company_number", companyNumbers);
		//If supabase throwsz
		if (error) throw error;

		const uniqueClients = [
			...new Map(data.map((c) => [c.company_number, c])).values(),
		];
		return uniqueClients;
	} catch (err) {
		console.error("Error fetching stored clients:", err.message);
		throw new Error("Failed to fetch clients");
	}
};

//compare changed fields
const compareFields = (oldData, newData) => {
	try {
		return FIELD_MAPPINGS.reduce((changes, {
			oldPath,
			newPath
		}) => {
			let oldVal = getNested(oldData, oldPath);
			let newVal = getNested(newData, newPath);

			if (newVal == null) return changes; // consult lord

			if (oldPath === "client_type" && COMPANY_TYPE_MAPPING[newVal]) {
				newVal = COMPANY_TYPE_MAPPING[newVal];
			}

			const sanitizedOld = sanitizeValue(oldVal);
			const sanitizedNew = sanitizeValue(newVal);

			const changed =
				Array.isArray(sanitizedOld) && Array.isArray(sanitizedNew) ?
				JSON.stringify(sanitizedOld) != JSON.stringify(sanitizedNew) :
				sanitizedOld != sanitizedNew;

			if (changed) {
				changes.push({
					field: oldPath,
					oldValue: oldVal,
					newValue: newVal
				});
			}

			return changes;
		}, []);


	} catch (error) {
		console.error("Error in compareFields:", error.message);
		return [];
	}
};

//Update nested services
const updateChosenServices = async (clientId, {
	name,
	updateTasks,
	changedFields,
	refField
},
newTaskNames) => {

	const batchQueries = [];

	let {
		data: [service],
		error
	} = await supabase
		.from("chosen_services")
		.select(
			`
      id,
      custom_fields
    ${updateTasks ? columnsForTaskUpdate : ''}`
		)
		.eq("client", clientId)
		.eq("name", name).limit(1);

	if (error) {
		throw error;
	}
	if (!service) {
		return;
	}

	
	//Get new object of customFields
	const updatedFields = updateCustomFields(
		service?.custom_fields,
		changedFields
	);

	const nextAccountsField = changedFields.find(({
		field
	}) => field == "next_accounts_end_on");


	//Unique update case if this field is changed
	if (nextAccountsField?.newValue) {
		// Parse the base date at UTC midnight
		const baseDate = new Date(nextAccountsField.newValue + "T00:00:00.000Z");

		// Add 12 months for CT600 deadline
		const ct600DeadlineDate = new Date(baseDate);
		ct600DeadlineDate.setUTCMonth(ct600DeadlineDate.getUTCMonth() + 12);
		const ct600Deadline = ct600DeadlineDate.toISOString();

		// Add 9 months and 1 day for HMRC payment date
		const hmrcPaymentDateDate = new Date(baseDate);
		hmrcPaymentDateDate.setUTCMonth(hmrcPaymentDateDate.getUTCMonth() + 9);
		hmrcPaymentDateDate.setUTCDate(hmrcPaymentDateDate.getUTCDate() + 1);
		const hmrcPaymentDate = hmrcPaymentDateDate.toISOString();

		// Assign to fields
		const ct600Field = updatedFields.find(
			(f) => f.token === "::CT600 Filing Deadline::"
		);
		if (ct600Field) ct600Field.date_val = ct600Deadline;

		const hmrcField = updatedFields.find(
			(f) => f.token === "::HMRC CT Payment Date::"
		);
		if (hmrcField) hmrcField.date_val = hmrcPaymentDate;
	}




	
	const referenceDate = changedFields.find(({
		field
	}) => field === refField)?.newValue;

	if (!updateTasks) {
		//call an rpc;

		await supabase
		.from("chosen_services")
		.update({
			custom_fields: updatedFields
		})
		.eq("id", service.id);
		
		const {data} =  await supabase.schema("for_tasks").rpc("refresh_ch_tasks",{
			p_reference_date: referenceDate,
			p_client_id : clientId,
			p_chosen_service : service.id
		});

		newTaskNames.push(data);
		return;

	}
	
	batchQueries.push(supabase
	.from("chosen_services")
	.update({
		custom_fields: updatedFields
	})
	.eq("id", service.id));
	

	if (!referenceDate) return;

	//batch updating all reminders where service = this service"  
	if (service.reminders.length > 0) {
		batchQueries.push(supabase.from("reminders").update({
			reference_date: referenceDate
		}).eq("service", service.id));
	}


	for (let reminder of service.reminders) {
		for (let email of reminder.email_datas) {

			const template = email.email_template_data;

			// Properly apply the sign based on is_before
			const offsetDays = (template.offset_days || 0) * (template.is_before ? -1 : 1);

			// Parse referenceDate as UTC midnight
			const date = new Date(referenceDate + "T00:00:00.000Z");

			// Add the offset
			date.setUTCDate(date.getUTCDate() + offsetDays);

			// Format as YYYY-MM-DD (UTC)
			const newDate = date.toISOString()

			// Queue the update queries
			batchQueries.push(
				supabase.from("email_datas").update({
					sending_date: newDate
				}).eq("id", email.id)
			);

			batchQueries.push(
				supabase.from("email_searchs").update({
					sending_date: newDate
				}).eq("email_data", email.id)
			);
		}
	}



	//UPDATING TASKS
	for (let task of service.tasks) {


		const freq = task?.frequency_settings;
		if (!freq) continue;

		const updatePayload = {
			reference_date: referenceDate
		};

		// Parse referenceDate as UTC
		const baseDate = new Date(referenceDate + "T00:00:00.000Z");

		// --- Internal deadline calculation
		if (freq.i_deadline_reference_status == null) {
			const iDeadlineDate = new Date(baseDate);
			iDeadlineDate.setUTCDate(iDeadlineDate.getUTCDate() + (freq.i_deadline_offset_days || 0));
			const iDeadline = iDeadlineDate.toISOString();
			updatePayload.i_deadline = iDeadline;

			if (freq.e_deadline_settings === "Internal") {
				updatePayload.e_deadline = iDeadline;
			}
		}

		// --- External deadline calculation
		if (freq.e_deadline_settings !== "Internal") {

			let eDeadlineDate = new Date(baseDate); // start from base

			switch (freq.e_deadline_settings) {
				case "Offset":
					eDeadlineDate.setUTCDate(
						eDeadlineDate.getUTCDate() + (freq.e_deadline_offset_days || 0)
					);
					break;

				case "Month":
					eDeadlineDate.setUTCMonth((freq.e_deadline_custom_month || 1) - 1);
					// Optionally keep the same day-of-month from baseDate
					eDeadlineDate.setUTCDate(baseDate.getUTCDate());
					break;

				case "Day":
					eDeadlineDate.setUTCDate(freq.e_deadline_custom_day || 1);
					break;
			}

			updatePayload.e_deadline = eDeadlineDate.toISOString();
		}

		// Queue the task update
		batchQueries.push(
			supabase.from("tasks").update(updatePayload).eq("chosen_service", service.id)
		);

	}

	return Promise.all(batchQueries);

}


//Update the client data
const updateClientData = async (clientId,changedFields) => {

		const newTaskNames = [];
		await supabase
		.from("clients")
		.update(
			Object.fromEntries(
			changedFields.map(({ field, newValue }) => [field, newValue])
			)
		)
		.eq("id", clientId)
		.select();

		await Promise.all(CH_SERVICES.map(async (service) =>{

			let obj = null;

			const fieldsOfInterest = changedFields.filter(({
				field
			}) => service.fields.includes(field));

			if (fieldsOfInterest.length == 0) return null;

			const updateTasks = !fieldsOfInterest.some(({
					field
				}) => field == service.keyField) 

				obj = {
					name: service.name,
					updateTasks,
					changedFields: fieldsOfInterest,
					refField: service.refField
				};
				
			await updateChosenServices(clientId,obj,newTaskNames); //returns a promise
		}));

		return newTaskNames;

};

// ----------------------------------
// Lambda Handler
// ----------------------------------
export const handler = async (event) => {
	try {

		const {
			companyNumbers
		} = JSON.parse(event.body);
		//If company numbers is 
		if (!Array.isArray(companyNumbers) || companyNumbers.length == 0) {

			console.log("Early return!");
			return {
				statusCode: 400,
				body: JSON.stringify({
					error: "Invalid input"
				}),
			};
		}
		// ------------------------------------------
		// Fetch Supabase clients and CH data in parallel
		// ------------------------------------------
		const [storedClients, companyResults] = await Promise.all([
			fetchStoredClients(companyNumbers),
			Promise.allSettled(
				companyNumbers.map(async (companyNumber) => {
					const data = await fetchCompanyData(companyNumber);
					return {
						companyNumber,
						data
					};
				})
			),
		]);

		
		const resultsOfUpdate = await Promise.all(storedClients.map(async (client) => {

			try
			{
				const data = companyResults.find(item => item.status == "fulfilled" && item.value.companyNumber == client.company_number)?.value?.data;
				if (data) {

					const changedFields = compareFields(client, data);
					console.log({changedFields});
					if (changedFields.length > 0)
					{
						const newTaskNames = await updateClientData(client.id,changedFields);

						return {
							clientId : client.id,
							skipped : false,
							changedFields,
							newTaskNames
						};	
					}
				}

				return 	{
							clientId: client.id,
							skipped: true
						};

			}
			catch(error)
			{
				return  {
							clientId : client.id,
							error : error.message
						};
			}

		

		}));

		const results = resultsOfUpdate?.map((oneResult) => {

			if (!oneResult.error) {
				return {
					...oneResult,
					updateStatus: "success",
				};
			}

			return {
				clientId:oneResult.clientId,
				updateStatus: "failed",
				updateError: oneResult.error,
			};
		});		
		return {
			statusCode: 200,
			body: JSON.stringify({
				results
			}),
		};
	} catch (err) {
		console.log("Error caught ->",err.message);
		return {
			statusCode: 500,
			body: JSON.stringify({
				error: err.message
			})
		};
	}
};